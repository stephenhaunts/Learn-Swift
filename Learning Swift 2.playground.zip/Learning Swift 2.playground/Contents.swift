import Cocoa

///////////////////////////////////////////////////////////////////////////
//
// Section 2 : Functions and Closures
//
///////////////////////////////////////////////////////////////////////////

/////////////////////////////
// Functions
////////////////////////////

// Simple function that take 1 string parameter but doesn't return anything. Function parameters are defined as contants by default, so you can not go an accidentally change these values.
func helloworld(name: String)
{
    let helloMessage = "Hello World. How are you doing \(name)."
    print (helloMessage)
}

helloworld (name: "Stephen Haunts")

// Sinple function that takes 1 string parameters and returns a string.
func helloworld2(name: String) -> String
{
    let helloMessage = "Hello World. How are you doing \(name)."
    return helloMessage
}

let returnValue = helloworld2(name: "Stephen Haunts")


// Simple function that takes a string and int parameter and returns a string.
func helloworld3(name: String, age: Int) -> String
{
    let helloMessage = "Hello World. How are you doing \(name). You are \(age) years old"
    return helloMessage
}

let returnValue2 = helloworld3(name: "Stephen Haunts", age: 40)


// If you need to return multiple values from a function, you can use a tuple to return names fields.
func helloworld4(name: String, age: Int) -> (message: String, name: String, age: Int)
{
    let helloMessage = "Hello World. How are you doing \(name). You are \(age) years old"
    return (helloMessage, name, age)
}

let replyTuple = helloworld4(name: "Stephen Haunts", age: 40)
print("Original Message \(replyTuple.message)")
print("Original Name \(replyTuple.name)")
print("Original Age \(replyTuple.age)")


// If you don't want to specify a parameter name when calling a function, put an _ infront of the parameter name, separated by a space.
func helloworld5(_ name: String, _ age: Int) -> String
{
    let helloMessage = "Hello World. How are you doing \(name). You are \(age) years old"
    return helloMessage
}

helloworld5("Stephen Haunts", 40)


// You can provide default values for parameters so that you don't have to specify them when you call the function if the default is all that is required.
func helloworld6(_ name: String, _ age: Int = 40) -> String
{
    let helloMessage = "Hello World. How are you doing \(name). You are \(age) years old"
    return helloMessage
}

let defaultParamReply1 : String = helloworld6("Stephen Haunts")
let defaultParamReply2 : String = helloworld6("Stephen Haunts", 50)


// You can also provide what is known as a variadic parameter where you can provide a sequence of a type. This is denoted with the ... syntax. You can only have one of these per function definition
func numberSequence (_ numbers : Int...)
{
    for number in numbers
    {
        print (number)
    }
}

numberSequence(1, 2, 3, 4, 5, 6, 7)

