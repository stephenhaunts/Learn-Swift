// Stephen Haunts
import Cocoa
import Foundation


///////////////////////////////////////////////////////////////////////////
//
// Section 1 : Language Basics
//
///////////////////////////////////////////////////////////////////////////

// In this section we introduce some swift language basics to get you started. Once you
// understand the concepts from this section you will be well on your way to start writing
// swift applications.

////////////////////////////
// Variables and Constants
////////////////////////////

// Variable declaration in Swift are able to infer what their type is by what you assign to it. In the following example str is inferred as a string because we assign the value "Hello, playground".
var str = "Hello, playground"

// The var keyword means you are defining a variable with a value that can change over time, i.e. You can reassign the value later.

// In the following example age is infered as an int because we assign the value 30.
var age = 30

// On ints and other numeric types we can perform basic arithmetic such as addition, subtraction, multiplication and division.
age
age = age + 10

// Constants in swift are defined with the let keyword. Once a constant value is assigned you can not change the value. In the example below, the constant const_age is assigned to 40, and after that you can no longer change the value. Constants are useful for values that you know will never need to change.
let const_age = 40

// Swift fully support unicode which means you can use emoji and other character sets like japanese in your variable / constant assignments.
let dog = "🐶🐶🐶🐶🐶"

// You can also use emoji to name variables and constants. Not really sure why you would want to do this, but fun, none the less.
let 🐶🐶 = "🐶🐶🐶🐶🐶"

// Swift has great support for strings, which are containers for text.
let myName = "Stephen Haunts"
var myFriend = "Daniel"

// Variables and constants also have some operations you can perform on them, such as converting a string to upper case or lowercase.
myName.uppercased()
myName.lowercased()

// You can create strings and also combine values from other variables in that string. This is caled String Interpolation. You do this by using the \() notation.
var infoAboutMe = "My name is \(myName) and I am \(age) years old"

// Numeric Types
var myNumber = 40
myNumber * 2

var wallet = 0.0
wallet += 10.0



// Explicity Defined Types
var number : Int = 20
var string : String = "blah blah"

// Type Aliases
typealias Money = Decimal
var moneyAmount : Money = 19.99

////////////////////////////
// Basic Math Operations
////////////////////////////
10 / 3
10 * 3
(2+2) * 2

10.0 / 3

var a : Int = 10
var b : Int = 20
var c : Int = a + b

var f : Float = 10.0
var r : Float = f / 3

r.round(FloatingPointRoundingRule.down)

var d : Double = 10.3


// Mixing Floats, Ints and Doubles
var qq : Int = 10
var ww : Double = 192.75

Double(qq) * ww


// Floor / Ceil(uses Foundation) / Power

let qqq : Double = 192.6748678
floor(qqq) // round down
ceil(qqq) // round up

pow(5, 2) // raise number to a power


////////////////////////////
// Boolean and If statements
////////////////////////////
var sunny : Bool = true

if (sunny == true)
{
    print("It's Sunny")
}
else
{
    print("It's not Sunny")
}


var aa : Int = 10
var bb : Int = 5

aa < bb
aa == bb
aa > bb


if (aa < bb)
{
    print("11 < bb")
}
else if (aa == bb)
{
    print("aa == bb")
}
else if (aa > bb)
{
    print("aa > bb")
}

////////////////////////////
// Switch statements
////////////////////////////
let grade = "a"

switch grade.uppercased()
{
    case "A":
        print("A, Great Job")
    case "B":
        print("B, Good Job")
    case "C":
        print("C, Good Job")
    case "D":
        print("D, Not Good")
    case "E":
        print("E, Not Good At All")
    case "F":
        print("F, Terrible!!")
    default:
        print("INVALID GRADE")
}


// Multiple Matching
let letter = "A"

switch letter.lowercased(){
    case "a","e","i","o","u":
        print ("Vowel")
    default:
        print ("Consonant")
}

// Interval Matching
let myAge = 40
switch myAge{
case 1...5:
    print ("Toddler")
case 6...17:
    print ("Child")
case 18...65:
    print ("Adult")
case 66...150:
    print ("Old Age Pensioner")
default:
    print ("Hello")
}


// Tuples
var errorCode = (404, "Not Found")

// No message binding for 2nd tuple parameter
switch errorCode
{
    case (404,_):
        print ("Error : Not Found")
    default:
        print("Invalid Error Code")
}

// Message binding of 2nd tuple parameter means we can access this value as a constant in the case
switch errorCode
{
case (404, let msg):
    print ("Error : \(msg)")
default:
    print("Invalid Error Code")
}

////////////////////////////
// Arrays, Dictionaries
////////////////////////////
var movies  = ["Star Wars", "Sharknado", "Saw"]
var moviesExplicit : [String] = ["Star Wars", "Sharknado", "Saw"]

let numbers = [1, 2, 3, 4, 5, 6, 7, 8, 9]
let numbersExplicit : [Int] = [1, 2, 3, 4, 5, 6, 7, 8, 9]

var bools = [true, true, false, true]

movies.append("Snowden")
movies.insert("Empire Strikes Back", at: 1)
movies.count
movies.remove(at: 2)
movies.count
movies.contains("Saw")
movies.contains("Aliens")

movies[1]
movies[0] = "Star Wars : A New Hope"
movies.first
movies.last
movies
movies.index(of : "Snowden")

// doesn't exist
movies.index(of : "Mars Attacks")

// Strart with Empty Awway
var startWithEmpty = [String]()
startWithEmpty.count
startWithEmpty.append("First Element")
startWithEmpty.count
startWithEmpty.insert("Second Element", at: 1)
startWithEmpty.count

// Start with Empty Dictionary
var wordDictionary = [String: String]()
wordDictionary["ant"] = "A small insect"
wordDictionary["dog"] = "A four legged mammal"
wordDictionary
wordDictionary.count
wordDictionary.isEmpty
wordDictionary["dog"]


////////////////////////////
// Looping
////////////////////////////

// For Loops
let familyNames : [String] = ["Stephen", "Amanda", "Amy", "Daniel"]
for n in familyNames
{
    print("\(n)")
}

for (word, definition) in wordDictionary
{
    print("\(word) = \(definition)")
}

for key in wordDictionary.keys
{
    print("\(key)")
}

for value in wordDictionary.values
{
    print("\(value)")
}

// Count 1 to 10 (Closed Range Operator)
for tick in 1...10
{
    print("Closed Range Loop <\(tick)>")
}

// Count 1 to 9 (Half Open Range Operator)
for tick in 1..<10
{
    print("Half Open Range Loop <\(tick)>")
}

// use break to exit out of a loop early
for counter in 1...10
{
    if (counter == 4)
    {
        break
    }
    
    print("Break Out of Loop <\(counter)>")
}

// While Loops : Loop not guarenteed to run as guard checked first
var whileCounter = 0

while whileCounter < 10
{
    print("While Loop Count <\(whileCounter)>")
    whileCounter = whileCounter + 1
}

// Repeat While Loops : Loops will always execute atleast once
var repeatCounter = 0

repeat{
    print("Repeat Loop Count <\(repeatCounter)>")
    repeatCounter = repeatCounter + 1
} while (repeatCounter < 10)


////////////////////////////
// Enumerations
////////////////////////////

enum DaysOfWeek
{
    case monday
    case tuesday
    case wednesday
    case thursday
    case friday
    case saturday
    case sunday
}

enum Months
{
    case january, february, march, april, may, june, july, august, september, october, november, december
}

var day = DaysOfWeek.saturday
var day2 : DaysOfWeek = .tuesday

switch day{
    case .saturday, .sunday:
        print ("YAY Weekend!!")
    case .monday:
        print ("WE HATE MONDAYS!!")
    default:
        print ("Just another day at work.")
}

// Associated Values
enum BeerPrice
{
    case Lager(Decimal)
    case RealAle(Decimal)
    case Stout(Decimal)
}

var australianLager = BeerPrice.Lager(2.50)
var americanLager = BeerPrice.Lager(3.99)
var englishCountryAle = BeerPrice.RealAle(2.99)
var irishStout = BeerPrice.Stout(2.75)

////////////////////////////
// Optionals
////////////////////////////

// Optionals are used when a value might be absent. Similar concept to nullable in C#
let myConstant = "666"
let myConstant2 = "Hello"

// This gets converted ok, but the conversion will return an optional int (Int?)
let converted = Int(myConstant)

// This conversion fails, so we get nil because it returns an optional Int(?)
let failedConversion = Int(myConstant2)


// we might return a value from a database into this optional String
var emailAddress : String? = "first.last@email.com"

// If the database doesn't return anything, then the value would be nil. This is ok though because the value is optional. nil represents the absense of a value of that type.
emailAddress = nil

// This wont work because the variable is not defined as optional
// var notnillable : String = nil


if (emailAddress == nil)
{
    print("There is no email address present.")
}

// Forced Unwrapping - is when you definately know the variable has a value. You ise the ! syntax

emailAddress = "first.last@email.com"

if (emailAddress == nil)
{
    print("There is no email address present.")
}
else
{
    print("The email addess is \(emailAddress!).")
}

// Optional Binding - is where you find out if an optional contains a value, and if it does you assign it to a temporary value that is available as a constant or variable.


if let email = emailAddress
{
    print("The email addess is \(email).")
}
else
{
    print("There is no email address present.")
}

// Implicit Unwrapped Optionals - If you can guarentee an optional will have a value you can mark it as an implicit unwrapped optional, it var myVar : String! = "blah"

let weKnowThereIsAValue : String! = "This is my value."
let implicitValue : String = weKnowThereIsAValue; // Doesn't require force unwrapping.



