import Cocoa

///////////////////////////////////////////////////////////////////////////
//
// Section 2 : Structs, Classes and Inheritance
//
///////////////////////////////////////////////////////////////////////////

/////////////////////////////
// Structs and Classes
////////////////////////////


// Structs and Classes common features

// Store values using properties
// Define functionality using methods
// Use subscripts to get access to values
// Setup initial state using initializer (constructor)
// Be extended to expand their functionality beyond a default implementation
// Conform to protocols to provide standard functionality of a certain kind”

// Classes have these additional features

// Inheritance enables one class to inherit the characteristics of another.
// Type casting enables you to check and interpret the type of a class instance at runtime.
// Deinitializers enable an instance of a class to free up any resources it has assigned.
// Reference counting allows more than one reference to a class instance.”


struct Coordinates
{
    var x = 0
    var y = 0
}

class Town
{
    var name : String?;
    var position = Coordinates()
}

var myTown = Town()
myTown.name = "Belper"
myTown.position.x = 50;
myTown.position.y = 50

myTown.name
myTown.position.x
myTown.position.y

// Structs come with memberwise initialization where you can initialise members
var position = Coordinates(x:200, y:300)
position.x
position.y

// The main difference is that structs are value types and classes are reference types.
// When you make a copy of a value type, it copies all the data from the thing you are copying into the new variable. They are 2 seperate things and changing one does not affect the other
// When you make a copy of a reference type, the new variable refers to the same memory location as the thing you are copying. This means that changing one will change the other since they both refer to the same memory location

// Identify operators
// Classes are reference types so if you copy an instance to another variable, that variable holds a reference to the original
class Person
{
    var name : String?;
}

var person1 = Person()
person1.name = "Geoff"
var person2 = person1


// To tell if they are equal, use the === identity operator

// This is equal
person1 === person2

// Create new instance of Person
person2 = Person()
person2.name = "Frank"

// Now they are not equal
person1 === person2

// Properties


class Properties
{
    // This property is a standard variable
    var variableProperty : String = "Hello";
    
    // This propertry is a constand and can not be changed
    let constantProperrt : String = "Hello"
    
    // This is a lazy variable property. Hello World is not copied into the variable until the property is called
    lazy var lazyVariableProperty : String = "Hello World"
}




